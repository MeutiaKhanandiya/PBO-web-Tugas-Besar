<?php 
$film = array("film1.jpg","film2.jpg","film3.jpg");

$arrlength1 = count($film);


$link = array("S_Jumanji.php","S_Maze.php","S_Fallout.php");
$nama = array('Fadila Rahmawati [08]','Jihan Nabilla Paramita [15]','M. Daffa Attariq [22]','Rizqy Gilang C.S [27]');

$datafilm = array
(
	array('jumanji','comming soon','S_Jumanji.php','jumanji.jpg'),
	array('maze','comming soon','S_Maze.php','maze runner.jpg'),
	array('fallout','comming soon','S_Fallout.php','fallout.jpg'),
	array('incribles','now playing','S_film2.php','film2.jpg'),
	array('insidious','now playing','S_film1.php','film1.jpg'),	
	array('marrowbone','now playing','S_film3.php','film3.jpg')
);

error_reporting(0);
$Comingsoon = array(array("judul" => "jumanji", "gambar" => "jumanji.jpg", "sinopsis" => "Berkisah tentang empat remaja SMA, Spencer Alex Wolff, Fridge Ser Darius Blain, Bethany Madison Iseman dan Martha Morgan Turner, yang dihukum untuk merapikan sebuah ruangan di sekolah. Di dalamnya terdapat banyak barang yang sudah tak terpakai, termasuk satu buah konsol video game dengan kaset berjudul Jumanji. Lantaran penasaran, Fridge mengajak yang lain untuk mencoba permainan tersebut. Alih-alih bersenang-senang, keempatnya justru tersedot ke dalam permainan tersebut.", "youtube" => "https://www.youtube.com/embed/2QKg5SZ_35I"),
	array("judul" => "maze", "gambar" => "maze runner.jpg", "sinopsis" => "yang melibatkan masa lalunya sebagai mantan anggota Impossible Mission Force (IMF). Petualangan Ethan dimulai ketika misi IMF gagal dan dunia terancam hancur karena adanya perebutan benda yang bisa mengancam terjadinya perang nuklir Ethan pun harus bisa menyelesaikan misi penyelamatan dunia dengan diburu waktu serta harus menghadapi hadangan dari pembunuh dan mantan rekannya yang ingin dia gagal. Bukan cuma itu masih ada campur tangan dari agen CIA bernama August Walker (Henry Cavill).", "youtube" => "https://www.youtube.com/embed/4-BTxXm8KSg"),
	array("judul" => "fallout", "gambar" => "fallout.jpg", "sinopsis" => "The Death Cure mengambil cerita setelah pengkhianatan Teresa (Kaya Scodelario), yang telah bergabung dengan organisasi jahat WCKD - diucapkan Wicked Ia mencoba menemukan obat untuk penyakit Flare yang telah menghapus populasi manusia dan mengubahnya menjadi zombie. Sementara anggota geng lainnya memulai pelarian berani calon pelari Maze Runners, Teresa mengenakan mantel lab dan mengerjakan proyek ilmiah dengan Patricia Clarkson. Subjek tes mereka saat ini adalah", "youtube" => "https://www.youtube.com/embed/wb49-oV0F78")
	);
?>